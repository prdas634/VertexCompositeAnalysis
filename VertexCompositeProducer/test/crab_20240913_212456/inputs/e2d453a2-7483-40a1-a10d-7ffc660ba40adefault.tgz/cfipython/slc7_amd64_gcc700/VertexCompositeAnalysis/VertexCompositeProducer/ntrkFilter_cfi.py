import FWCore.ParameterSet.Config as cms

ntrkFilter = cms.EDFilter('MultFilter',
  primaryVertices = cms.InputTag('offlinePrimaryVertices'),
  nTracksVMap = cms.InputTag('generalParticles', 'nTracks'),
  nMultMin = cms.untracked.int32(0),
  nMultMax = cms.untracked.int32(2147483647),
  useCent = cms.untracked.bool(False),
  vtxSortByTrkSize = cms.untracked.bool(True),
  centrality = cms.untracked.InputTag('hiCentrality'),
  centralityBin = cms.untracked.InputTag('centralityBin', 'HFtowers'),
  centBinMin = cms.untracked.int32(0),
  centBinMax = cms.untracked.int32(2147483647)
)
