import FWCore.ParameterSet.Config as cms

nTracks = cms.EDProducer('NTrackVertexMapper',
  primaryVertices = cms.InputTag('offlinePrimaryVertices'),
  tracks = cms.InputTag('generalTracks')
)
