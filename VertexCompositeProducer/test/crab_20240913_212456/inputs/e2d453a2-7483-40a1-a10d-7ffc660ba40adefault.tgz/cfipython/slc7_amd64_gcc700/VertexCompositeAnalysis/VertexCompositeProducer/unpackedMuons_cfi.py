import FWCore.ParameterSet.Config as cms

unpackedMuons = cms.EDProducer('MuonUnpacker',
  muons = cms.InputTag('slimmedMuons'),
  triggerResults = cms.InputTag('TriggerResults', '', 'HLT')
)
