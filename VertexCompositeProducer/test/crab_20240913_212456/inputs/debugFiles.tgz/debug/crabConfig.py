from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'ppRun2UL_V0Both_MiniAOD_cfg_testPD.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['v0ana_wJet_test.root']
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/JetHT/Run2018D-UL2018 MiniAODv2-v2/MINIAOD'
config.Data.publication = False
config.Data.splitting = 'Automatic'
config.Data.inputDBS = 'https://cmsweb.cern.ch/dbs/prod/global/DBSReader'
config.Data.outLFNDirBase = '/store/group/phys_heavyions/prdas/Run2_v0_wjet_trees/'
config.Data.lumiMask = '/afs/cern.ch/work/p/prdas/private/V0Reco/Cert_314472-325175_13TeV_Legacy2018_Collisions18_JSON.txt'
config.section_('User')
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
